# Conferencias usadas para completar datos faltantes / Press briefings used to fill incomplete data.

|Fecha          | Enlaces  |
|---|---|
| 2020-02-28 | [Link](https://youtu.be/u02cFaPkhyE?t=1710) |
| 2020-02-29 | [Link](https://youtu.be/9N0Ti0XCiUs?t=1150) |
| 2020-03-10 | [Link](https://youtu.be/Mct2UgTyTNg?t=378) |
| 2020-03-11 | [Link](https://youtu.be/4MWoB-DdbgA?t=353) | 
| 2020-03-12 | [Link](https://youtu.be/Qk_U0iWaFH4?t=406) |
| 2020-03-13 | [Link](https://youtu.be/RiAjlECUyfw?t=326) |
| 2020-03-14 | [Link](https://youtu.be/eYGgQRokyEI?t=262) |
| 2020-03-15 | [Link](https://youtu.be/rjl26k3PhFQ?t=206) |
| 2020-03-19 | [Link](https://youtu.be/DbDNrf4z8YM?t=519) (Mención de la muerte del primer paciente; mención del fallecimiento de un caso sospechoso) |
| 2020-03-20 | [Link](https://youtu.be/f79tm7-c-_Q?t=126) (Mención de la entidad del segundo paciente) |
