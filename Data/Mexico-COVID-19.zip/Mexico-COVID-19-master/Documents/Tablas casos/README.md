# Tablas de casos sospechosos y casos confimados / Tables of suspected cases and confirmed cases.

Última actualización: 2020-03-31 T 19:40:00-06:00

Los datos para los cuales no se tienen las tablas fueron obtenidos de las conferencias mostradas en ```Conferencias.md```.

The data for which we currently have no tables was collected from the press briefings listed in ```Conferencias.md```.
