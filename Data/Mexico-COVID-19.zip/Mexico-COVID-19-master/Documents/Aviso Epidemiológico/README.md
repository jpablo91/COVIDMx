# Avisos epidemiologicos / Epidemiological notices

Última actualización: 2020-03-26 T 02:10:00-06:00 

Archivos relacionados a avisos epidemiológicos de la Secretaría de Salud del gobierno federal. [Link](https://www.gob.mx/salud/documentos/aviso-epidemiologico-casos-de-infeccion-respiratoria-asociados-a-nuevo-coronavirus-2019-ncov)

Files related to epidemiological notices of the Heath Secretariat of the federal government.  [Link](https://www.gob.mx/salud/documentos/aviso-epidemiologico-casos-de-infeccion-respiratoria-asociados-a-nuevo-coronavirus-2019-ncov)


